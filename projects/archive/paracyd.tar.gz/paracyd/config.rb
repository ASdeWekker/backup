require "compass/import-once/activate"

http_path = "/"
css_dir = "/"
sass_dir = "/"
images_dir = "/"
javascripts_dir = "/"

line_comments = false
